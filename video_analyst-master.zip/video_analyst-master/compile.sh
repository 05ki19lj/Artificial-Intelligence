# complie evaluation toolkit
pushd videoanalyst/evaluation/vot_benchmark
bash make.sh
popd