
## Archived Models

### VOT2018

| Backbone | Pipeline | Dataset | A | R | EAO | FPS@GTX2080Ti | FPS@GTX1080Ti | Config. Filename | Model Filename |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| AlexNet | SiamFCppTracker | VOT2018 |0.588 | 0.243 | 0.373| ~200| ~185 | siamfcpp_alexnet.yaml | siamfcpp-alexnet-vot-md5_18fd31a2f94b0296c08fff9b0f9ad240.pkl|
| GoogLeNet | SiamFCppTracker | VOT2018 | 0.588 | 0.183 | 0.437 | ~80 | ~65 | siamfcpp_googlenet-new.yaml | siamfcpp-googlenet-vot-md5_e14e9b6c82799602d777fd21a081c907.pkl |
