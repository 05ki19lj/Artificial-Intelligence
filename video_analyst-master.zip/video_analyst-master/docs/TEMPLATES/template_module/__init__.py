# -*- coding: utf-8 -*-
from .template_module_impl import *  # noqa
