#!/usr/bin/env bash

python3 ./main/test.py --config 'experiments/sat/test/sat_res50-davis17.yaml'

