#!/usr/bin/env bash
python3 ./main/test.py --config 'experiments/siamfcpp/test/otb/siamfcpp_alexnet-otb.yaml'
python3 ./main/test.py --config 'experiments/siamfcpp/test/otb/siamfcpp_googlenet-otb.yaml'
