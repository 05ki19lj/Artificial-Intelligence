#!/usr/bin/env bash
python3 ./main/test.py --config 'experiments/siamfcpp/test/lasot/siamfcpp_googlenet-lasot.yaml'
